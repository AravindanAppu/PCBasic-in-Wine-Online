PC-BASIC package data
=====================

This directory contains the data that is needed to run a PC-BASIC session without an interface.
This includes a default ROM font of 8x8 pixels, a default codepage mapping (for codepage 437)
as well as copyright and release metadata.


Acknowledgements
----------------

The glyphs encoded in `font.json` were extracted from Henrique Peron's CPIDOS v3.0,

CPIDOS is distributed with FreeDOS at
-   http://www.freedos.org/software/?prog=cpidos
-   http://www.ibiblio.org/pub/micro/pc-stuff/freedos/files/dos/cpi/

CPIDOS is Copyright (C) 2002-2011 by Henrique Peron (hperon@terra.com.br)
and licensed under the GNU GPL version 2 or later.
