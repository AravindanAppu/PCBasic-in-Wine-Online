PC-BASIC application data
=========================

This directory contains the data that is bundled with the PC-BASIC application.

This includes:
- the application default font (which is not the same as the ROM font)
- alternative fonts
- codepage mappings
- BASIC programs
