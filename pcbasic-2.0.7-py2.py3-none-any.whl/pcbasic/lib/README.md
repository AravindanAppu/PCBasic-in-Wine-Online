External libraries
==================

`SDL2` and `SDL2_gfx` libraries should be placed in your operating system's usual location.
If that does not work, you can place a copy of the libraries for your system in this directory.
